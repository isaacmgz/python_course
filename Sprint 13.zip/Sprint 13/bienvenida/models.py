from django.db import models

class Owner(models.Model):
    name = models.CharField(max_length=100)
    phone = models.CharField(max_length=15)
    address = models.CharField(max_length=255)
class Mascota(models.Model):
    name = models.CharField(max_length=100)
    species = models.CharField(max_length=50)
    breed = models.CharField(max_length=50)
    age = models.PositiveIntegerField()
    owner = models.ForeignKey(Owner, on_delete=models.CASCADE, related_name='mascotas')

class Cita(models.Model):
    date = models.DateField()
    time = models.TimeField()
    owner = models.ForeignKey(Owner, on_delete=models.CASCADE, related_name='citas')
    mascota = models.ForeignKey(Mascota, on_delete=models.CASCADE, related_name='citas')

class Medicamento(models.Model):
    nombre = models.CharField(max_length=100)
    descripcion = models.TextField(blank=True)
    dosis = models.CharField(max_length=100, blank=True)
    fecha_registro = models.DateField(auto_now_add=True)

    def __str__(self):
        return self.nombre

class Veterinario(models.Model):
    nombre = models.CharField(max_length=100)

    def __str__(self):
        return self.nombre

class Cirugia(models.Model):
    mascota = models.ForeignKey('Mascota', on_delete=models.CASCADE)
    veterinario = models.ForeignKey(Veterinario, on_delete=models.CASCADE)
    fecha = models.DateField()
    hora = models.TimeField()
    descripcion = models.TextField(blank=True)

    def __str__(self):
        return f"Cirugía de {self.mascota.name} con {self.veterinario.nombre} el {self.fecha}"

class BitacoraConsulta(models.Model):
    mascota = models.ForeignKey(Mascota, on_delete=models.CASCADE, related_name='bitacoras')
    fecha = models.DateTimeField(auto_now_add=True)
    observaciones = models.TextField()
    diagnostico = models.TextField()
    tratamiento = models.TextField()

    def __str__(self):
        return f"Bitácora de {self.mascota.name} - {self.fecha.strftime('%Y-%m-%d %H:%M')}"