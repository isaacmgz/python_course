from django.urls import path
from . import views

urlpatterns = [
    path('', views.BienvenidaView.as_view(), name='bienvenida'),
    path('servicios/', views.ServiciosView.as_view(), name='servicios'),
    path('elegir-tipo-cita/', views.elegir_tipo_cita, name='elegir_tipo_cita'),
    path('registro-dueno/', views.registro_dueno, name='registro_dueno'),
    path('registro-mascota/', views.registro_mascota, name='registro_mascota'),
    path('seleccionar-dia/', views.seleccionar_dia, name='seleccionar_dia'),
    path('seleccionar-horario/', views.seleccionar_horario, name='seleccionar_horario'),
    path('elegir-horario/', views.elegir_horario, name='elegir_horario'),
    path('confirmacion-cita/<int:cita_id>/', views.confirmacion_cita, name='confirmacion_cita'),
    path('conoce-mas/', views.conoce_mas, name='conoce_mas'),
    path('lista-duenos/', views.lista_duenos, name='lista_duenos'),
    path('lista-medicamentos/', views.lista_medicamentos, name='lista_medicamentos'),
    path('crear-medicamento/', views.crear_medicamento, name='crear_medicamento'),
    path('editar-medicamento/<int:pk>/', views.editar_medicamento, name='editar_medicamento'),
    path('eliminar-medicamento/<int:pk>/', views.eliminar_medicamento, name='eliminar_medicamento'),
    path('seleccionar-veterinario/', views.seleccionar_veterinario, name='seleccionar_veterinario'),
    path('confirmacion-cirugia/', views.confirmacion_cirugia, name='confirmacion_cirugia'),
    path('confirmar-cita/', views.confirmar_cita, name='confirmar_cita'),
    path('lista-mascotas/', views.lista_mascotas, name='lista_mascotas'),
    path('bitacora/<int:mascota_id>/', views.historia_mascota, name='historia_mascota'),
    path('bitacora/<int:mascota_id>/agregar/', views.agregar_bitacora, name='agregar_bitacora'),
    path('exportar-duenos/', views.exportar_duenos_csv, name='exportar_duenos_csv'),
    path('exportar-mascotas/', views.exportar_mascotas_csv, name='exportar_mascotas_csv'),
]