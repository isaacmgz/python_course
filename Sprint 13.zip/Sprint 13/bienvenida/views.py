from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from django.views import View
from .models import Owner, Mascota, Cita, Medicamento, Veterinario, Cirugia
from .forms import MedicamentoForm, BitacoraConsultaForm
from datetime import date, timedelta, time, datetime
import csv

class BienvenidaView(View):
    def get(self, request):
        return render(request, 'bienvenida/bienvenida.html')

class ServiciosView(View):
    def get(self, request):
        return render(request, 'bienvenida/servicios.html')

def registro_dueno(request):
    if request.method == 'POST':
        name = request.POST['name']
        phone = request.POST['phone']
        address = request.POST['address']
        owner = Owner.objects.create(name=name, phone=phone, address=address)
        request.session['owner_id'] = owner.id
        return redirect('registro_mascota')
    return render(request, 'bienvenida/registro_dueno.html')

def registro_mascota(request):
    owner_id = request.session.get('owner_id')
    if not owner_id:
        return redirect('registro_dueno')
    if request.method == 'POST':
        name = request.POST['name']
        species = request.POST['species']
        breed = request.POST['breed']
        age = request.POST['age']
        owner = Owner.objects.get(id=owner_id)
        mascota = Mascota.objects.create(name=name, species=species, breed=breed, age=age, owner=owner)
        request.session['mascota_id'] = mascota.id
        return redirect('elegir_tipo_cita')
    return render(request, 'bienvenida/registro_mascota.html')

def elegir_tipo_cita(request):
    if request.method == 'POST':
        tipo = request.POST.get('tipo_cita')
        request.session['tipo_cita'] = tipo
        if tipo == 'cirugia':
            return redirect('seleccionar_veterinario')
        else:
            return redirect('confirmar_cita')
    return render(request, 'bienvenida/elegir_tipo_cita.html')

def seleccionar_dia(request):
    dias = [date.today() + timedelta(days=i) for i in range(7)]
    print("DEBUG SESSION (seleccionar_dia):", dict(request.session))
    return render(request, 'bienvenida/seleccionar_dia.html', {'dias': dias})

def seleccionar_horario(request):
    dia = request.GET.get('dia')
    horarios = [time(10,0), time(11,0), time(12,0), time(14,0), time(15,0), time(16,0)]
    ocupados = Cita.objects.filter(date=dia).values_list('time', flat=True)
    disponibles = [h for h in horarios if h not in ocupados]
    print("DEBUG SESSION (seleccionar_horario):", dict(request.session))
    return render(request, 'bienvenida/seleccionar_horario.html', {'dia': dia, 'horarios': disponibles})

def elegir_horario(request):
    if request.method == 'POST':
        dia = request.POST['dia']
        horario = request.POST['horario']
        request.session['cita_dia'] = dia
        request.session['cita_horario'] = horario
        return redirect('registro_dueno')
    return redirect('seleccionar_dia')

def conoce_mas(request):
    fechas = [(date.today() + timedelta(days=i)).strftime('%Y-%m-%d') for i in range(7)]
    return render(request, 'bienvenida/conoce_mas.html', {'fechas': fechas})

def confirmacion_cita(request, cita_id):
    cita = Cita.objects.select_related('owner', 'mascota').get(id=cita_id)
    return render(request, 'bienvenida/confirmacion_cita.html', {'cita': cita})

def lista_medicamentos(request):
    medicamentos = Medicamento.objects.all()
    return render(request, 'bienvenida/lista_medicamentos.html', {'medicamentos': medicamentos})

def crear_medicamento(request):
    if request.method == 'POST':
        form = MedicamentoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('lista_medicamentos')
    else:
        form = MedicamentoForm()
    return render(request, 'bienvenida/crear_medicamento.html', {'form': form})

def editar_medicamento(request, pk):
    medicamento = get_object_or_404(Medicamento, pk=pk)
    if request.method == 'POST':
        form = MedicamentoForm(request.POST, instance=medicamento)
        if form.is_valid():
            form.save()
            return redirect('lista_medicamentos')
    else:
        form = MedicamentoForm(instance=medicamento)
    return render(request, 'bienvenida/editar_medicamento.html', {'form': form, 'medicamento': medicamento})

def eliminar_medicamento(request, pk):
    medicamento = get_object_or_404(Medicamento, pk=pk)
    if request.method == 'POST':
        medicamento.delete()
        return redirect('lista_medicamentos')
    return render(request, 'bienvenida/eliminar_medicamento.html', {'medicamento': medicamento})

def seleccionar_veterinario(request):
    nombres = ["Dr. Sebastian", "Dr. Isaac", "Dr. Jose"]
    for nombre in nombres:
        Veterinario.objects.get_or_create(nombre=nombre)

    veterinarios = Veterinario.objects.all()
    if request.method == 'POST':
        vet_id = request.POST.get('veterinario')
        descripcion = request.POST.get('descripcion')
        request.session['veterinario_id'] = vet_id
        request.session['cirugia_descripcion'] = descripcion
        return redirect('confirmacion_cirugia')
    return render(request, 'bienvenida/seleccionar_veterinario.html', {'veterinarios': veterinarios})

def confirmacion_cirugia(request):
    mascota_id = request.session.get('mascota_id')
    dia = request.session.get('cita_dia')
    horario = request.session.get('cita_horario')
    vet_id = request.session.get('veterinario_id')
    descripcion = request.session.get('cirugia_descripcion')

    # Validación de datos
    if not all([mascota_id, dia, horario, vet_id]):
        return HttpResponse("Faltan datos para registrar la cirugía. Por favor, repite el proceso.", status=400)

    mascota = Mascota.objects.get(id=mascota_id)
    veterinario = Veterinario.objects.get(id=vet_id)
    fecha_obj = datetime.strptime(dia, "%Y-%m-%d").date()
    if isinstance(horario, str):
        try:
            hora_obj = datetime.strptime(horario, "%H:%M").time()
        except ValueError:
            hora_obj = datetime.strptime(horario, "%I %p").time()
    else:
        hora_obj = horario

    cirugia = Cirugia.objects.create(
        mascota=mascota,
        veterinario=veterinario,
        fecha=fecha_obj,
        hora=hora_obj,
        descripcion=descripcion
    )

    return render(request, 'bienvenida/confirmacion_cirugia.html', {
        'cirugia': cirugia
    })

def lista_duenos(request):
    duenos = Owner.objects.all()
    cita_id = request.GET.get('cita_id')
    tipo = request.GET.get('tipo')
    return render(request, 'bienvenida/lista_duenos.html', {
        'duenos': duenos,
        'cita_id': cita_id,
        'tipo': tipo,
    })

def confirmar_cita(request):
    owner_id = request.session.get('owner_id')
    tipo_cita = request.session.get('tipo_cita')
    mascota_id = request.session.get('mascota_id')
    dia = request.session.get('cita_dia')
    horario = request.session.get('cita_horario')

    if not all([owner_id, tipo_cita, mascota_id, dia, horario]):
        return HttpResponse("Faltan datos para registrar la cita. Por favor, repite el proceso.", status=400)

    owner = Owner.objects.get(id=owner_id)
    mascota = Mascota.objects.get(id=mascota_id)
    horario_obj = datetime.strptime(horario, "%H:%M").time() if isinstance(horario, str) else horario
    cita = Cita.objects.create(date=dia, time=horario_obj, owner=owner, mascota=mascota)
    for key in ['cita_dia', 'cita_horario', 'owner_id', 'mascota_id', 'tipo_cita']:
        if key in request.session:
            del request.session[key]
    return redirect('confirmacion_cita', cita_id=cita.id)

def lista_mascotas(request):
    mascotas = Mascota.objects.all()
    cita_id = request.GET.get('cita_id')
    tipo = request.GET.get('tipo')
    return render(request, 'bienvenida/lista_mascotas.html', {
        'mascotas': mascotas,
        'cita_id': cita_id,
        'tipo': tipo,
    })

def historia_mascota(request, mascota_id):
    mascota = Mascota.objects.get(id=mascota_id)
    bitacoras = mascota.bitacoras.all() if hasattr(mascota, 'bitacoras') else []
    return render(request, 'bienvenida/historia_mascota.html', {
        'mascota': mascota,
        'bitacoras': bitacoras,
    })

def agregar_bitacora(request, mascota_id):
    mascota = Mascota.objects.get(id=mascota_id)
    if request.method == 'POST':
        form = BitacoraConsultaForm(request.POST)
        if form.is_valid():
            bitacora = form.save(commit=False)
            bitacora.mascota = mascota
            bitacora.save()
            return redirect('historia_mascota', mascota_id=mascota.id)
    else:
        form = BitacoraConsultaForm()
    return render(request, 'bienvenida/agregar_bitacora.html', {'form': form, 'mascota': mascota})

def exportar_duenos_csv(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="duenos.csv"'

    writer = csv.writer(response)
    writer.writerow(['ID', 'Nombre', 'Teléfono', 'Dirección'])

    for dueno in Owner.objects.all():
        writer.writerow([dueno.id, dueno.name, dueno.phone, dueno.address])

    return response

def exportar_mascotas_csv(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="mascotas.csv"'

    writer = csv.writer(response)
    writer.writerow(['ID', 'Nombre', 'Especie', 'Raza', 'Edad', 'Dueño'])

    for mascota in Mascota.objects.select_related('owner').all():
        writer.writerow([
            mascota.id,
            mascota.name,
            mascota.species,
            mascota.breed,
            mascota.age,
            mascota.owner.name
        ])

    return response

