from django.contrib import admin
from .models import Owner, Mascota, Cita, Medicamento, Veterinario, Cirugia, BitacoraConsulta

admin.site.register(Owner)
admin.site.register(Mascota)
admin.site.register(Cita)
admin.site.register(BitacoraConsulta)

@admin.register(Medicamento)
class MedicamentoAdmin(admin.ModelAdmin):
    list_display = ('nombre', 'dosis', 'fecha_registro')
    search_fields = ('nombre',)

admin.site.register(Veterinario)
admin.site.register(Cirugia)

